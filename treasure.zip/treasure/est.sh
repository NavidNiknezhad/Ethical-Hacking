#!/bin/bash
for i in {1..50}
do
	mkdir dir$i
	for j in {1..50}
	do
		cp ../magic dir$i/magic$j
	done
done
